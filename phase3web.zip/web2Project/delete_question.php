<?php
session_start();
include("db_connect.php");

if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'educator'){
    echo "false";
    exit();
}
// PHP page: fetch sent data
$questionID = isset($_POST['questionID']) ? intval($_POST['questionID']) : 0;

if($questionID <= 0){
    echo "false";
    exit();
}

// حذف الصورة لو موجودة
$getFile = mysqli_query($conn, "SELECT questionFigureFileName FROM QuizQuestion WHERE id = $questionID");
if($getFile && mysqli_num_rows($getFile) > 0){
    $fileRow = mysqli_fetch_assoc($getFile);
    $fileName = $fileRow['questionFigureFileName'];
    if(!empty($fileName) && file_exists("image/" . $fileName)){
        unlink("image/" . $fileName);
    }
}

// PHP page: delete quiz question
$delete = mysqli_query($conn, "DELETE FROM QuizQuestion WHERE id = $questionID");


// PHP page: returns true
if($delete){
    echo "true";  
} else {
    echo "false";
}
?>
