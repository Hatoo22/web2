<?php
session_start();
include 'db_connect.php';

header("Content-Type: application/json");

// Check login
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'educator') {
    echo json_encode(["success" => false, "message" => "unauthorized"]);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "invalidRequest"]);
    exit();
}

$recommendID = intval($_POST['recommendID']);
$status = $_POST['status'] ?? '';
$comment = trim($_POST['comment'] ?? '');

if (empty($recommendID) || empty($status)) {
    echo json_encode(["success" => false, "message" => "missingData"]);
    exit();
}

// 1. Get recommended question
$query = "SELECT * FROM recommendedquestion WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $recommendID);
$stmt->execute();
$recommend = $stmt->get_result()->fetch_assoc();

if (!$recommend) {
    echo json_encode(["success" => false, "message" => "notfound"]);
    exit();
}

// 2. Update status + comment
$update = "UPDATE recommendedquestion SET status = ?, comments = ? WHERE id = ?";
$stmt = $conn->prepare($update);
$stmt->bind_param("ssi", $status, $comment, $recommendID);
$stmt->execute();

// 3. If approved → insert into quizquestion
if ($status === 'approved') {
    $insert = "INSERT INTO quizquestion 
        (quizID, question, questionFigureFileName, answerA, answerB, answerC, answerD, correctAnswer)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($insert);
    $stmt->bind_param(
        "isssssss",
        $recommend['quizID'],
        $recommend['question'],
        $recommend['questionFigureFileName'],
        $recommend['answerA'],
        $recommend['answerB'],
        $recommend['answerC'],
        $recommend['answerD'],
        $recommend['correctAnswer']
    );
    $stmt->execute();
}

// SUCCESS response — needed by AJAX
echo json_encode(["success" => true, "message" => "reviewSaved"]);
exit();
?>