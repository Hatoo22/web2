<?php
session_start();      // تشغيل الجلسة الحالية
session_unset();      // حذف جميع متغيرات الجلسة
session_destroy();    // إنهاء الجلسة بالكامل

// إعادة التوجيه إلى الصفحة الرئيسية
header("Location: index.html");
exit();
?>

