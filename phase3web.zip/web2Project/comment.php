<?php

session_start();
if (empty($_SESSION['user_id'])) {
    // إعادة التوجيه إلى الصفحة الرئيسية
    header('Location: index.html'); // افترض أن homepage اسمها index.php
    exit();
}
include("db_connect.php"); // ملف الاتصال بقاعدة البيانات

$quizID = isset($_GET['quizID']) ? intval($_GET['quizID']) : 0;

$sql = "SELECT * FROM quizfeedback WHERE quizID = $quizID ORDER BY date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Comment page</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .com1 {
      border: 2px solid #b7b7b7;
      border-radius: 10px;
      box-shadow: 0 6px 2px rgba(0,0,0,.06);
      padding: 16px 20px;
      margin: 20px auto;
      max-width: 900px;
      width: 90%;
      display: flex;
      flex-direction: column;
      gap: 10px;
      position: relative;
    }

    .top {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .profile {
      width: 55px;
      height: 55px;
      border: 2px solid #b7b7b7;
      border-radius: 8px;
      object-fit: cover;
    }

    .name {
      font-size: 18px;
      font-weight: bold;
      color: #071b45;
      margin: 0;
    }

    .Comments {
      font-size: 16px;
      margin: 6px 0;
      text-align: left;
    }

    .bottom {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 8px;
    }

    .rating {
      font-size: 17px;
      font-weight: bold;
      color: #333;
    }

    .date {
      font-size: 14px;
      color: gray;
      text-align: left;
    }

    footer {
      margin-top: auto;
    }
  </style>
</head>

<body>
<header>
  <div class="logo">
    <img src="image/logo.png" alt="logo">
    <span>TechQuiz</span>
  </div>

  <div class="navbar">
    <a href="educator.php">Home</a>
  </div>

  <div class="logout">
    <a href="logout.php">Log out</a>
  </div>
</header>

<?php
if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    echo '<div class="com1">';
    echo '<div class="top">';
    echo '<img src="image/default.png" alt="profile" class="profile">';
    echo '<h3 class="name">Anonymous</h3>';
    echo '</div>'; // top

    echo '<p class="Comments">' . htmlspecialchars($row["comments"]) . '</p>';

    echo '<div class="bottom">';
    echo '<p class="date">' . date("d-m-Y H:i", strtotime($row["date"])) . '</p>';
    echo '<p class="rating">' . htmlspecialchars($row["rating"]) . '/5</p>';
    echo '</div>'; // bottom

    echo '</div>'; // com1
  }
} else {
  echo "<p style='text-align:center; font-size:18px;'>No comments found for this quiz.</p>";
}
?>

<footer>
  <div class="footer-left">
    <h4>Contact Us</h4>
    <p>📞 +966 5555 12345</p>
    <p>📧 TechQuiz@example.com</p>
  </div>
</footer>

</body>
</html>
