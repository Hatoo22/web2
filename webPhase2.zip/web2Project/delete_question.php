<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include("db_connect.php");

// --------------------------------------------------
// CHECK USER LOGIN AND ROLE
// --------------------------------------------------
if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'educator'){
    exit("Unauthorized access");
}

// --------------------------------------------------
// CHECKS THE ID THAT IS SENT IN THE QUERY STRING
// --------------------------------------------------
$quizID = isset($_GET['quizID']) ? intval($_GET['quizID']) : 0;
$questionID = isset($_GET['questionID']) ? intval($_GET['questionID']) : 0;

if($quizID <= 0 || $questionID <= 0){
    exit("Missing quizID or questionID");
}

// --------------------------------------------------
// DELETES QUESTION FIGURE IMAGE FROM THE SYSTEM
// --------------------------------------------------
$getFile = mysqli_query($conn, "SELECT questionFigureFileName FROM QuizQuestion WHERE id = $questionID");

if(!$getFile){
    die("Database error: " . mysqli_error($conn));
}

if(mysqli_num_rows($getFile) > 0){
    $fileRow = mysqli_fetch_assoc($getFile);
    $fileName = $fileRow['questionFigureFileName'];

    if(!empty($fileName) && file_exists("uploads/" . $fileName)){
        unlink("uploads/" . $fileName);
    }
}

// --------------------------------------------------
// DELETES THE CORRESPONDING QUESTION IN THE DATABASE
// --------------------------------------------------
if(!mysqli_query($conn, "DELETE FROM QuizQuestion WHERE id = $questionID")){
    die("Error deleting question: " . mysqli_error($conn));
}

// --------------------------------------------------
// REDIRECTS TO THE QUIZ PAGE
// --------------------------------------------------
header("Location: quiz.php?id=$quizID");
exit();
