<?php
session_start();
ini_set('display_errors',1);
error_reporting(E_ALL);

include 'db_connect.php';

// دالة رفع الصورة أو استخدام الصورة الافتراضية
function uploadProfile($file){
    $default = "default.png"; 
    if(isset($file) && $file['error']==0){
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $allowed = ['jpg','jpeg','png','gif'];
        if(!in_array(strtolower($ext), $allowed)) return $default;
        $newName = uniqid() . "." . $ext;
        move_uploaded_file($file['tmp_name'], "image/".$newName);
        return $newName;
    }
    return $default;
}

if($_SERVER['REQUEST_METHOD'] === "POST"){
    $first = trim($_POST['firstName'] ?? '');
    $last  = trim($_POST['lastName'] ?? '');
    $email = trim($_POST['emailAddress'] ?? '');
    $passwordRaw = $_POST['password'] ?? '';
    $type  = strtolower($_POST['userType'] ?? ''); // 
    $profile = uploadProfile($_FILES['photoFileName'] ?? null);
    $pass = password_hash($passwordRaw, PASSWORD_DEFAULT);

    // تحقق من وجود الإيميل مسبقًا
    $check = $conn->prepare("SELECT id FROM user WHERE emailAddress=?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if($check->num_rows > 0){
        $errType = ($type=="learner") ? "learner_exists" : "educator_exists";
        header("Location: signup.php?err=$errType");
        exit;
    }

    // إدخال المستخدم في قاعدة البيانات
    $stmt = $conn->prepare(
        "INSERT INTO user (firstName,lastName,emailAddress,password,photoFileName,userType) 
         VALUES (?,?,?,?,?,?)"
    );
    $stmt->bind_param("ssssss", $first, $last, $email, $pass, $profile, $type);
    $stmt->execute();
    $userId = $stmt->insert_id;
    $stmt->close();

    $_SESSION['user_id'] = $userId;
    $_SESSION['user_type'] = $type;
    session_write_close(); // يحفظ الجلسة قبل التوجيه

    // إدخال التخصصات للمعلم
    if($type=="educator" && isset($_POST['check'])){
        foreach($_POST['check'] as $topicID){
            $stmt2 = $conn->prepare("INSERT INTO quiz (educatorID, topicID) VALUES (?,?)");
            $stmt2->bind_param("ii", $userId, $topicID);
            $stmt2->execute();
            $stmt2->close();
        }
    }

    // توجيه المستخدم حسب النوع
    if($type=="learner"){
        header("Location: LernerHomepage.php");
    } else {
        header("Location: educator.php");
    }
    exit;
}
?>
