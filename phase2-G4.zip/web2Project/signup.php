<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign Up</title>
<style>
*{ padding: 0; margin: 0; box-sizing: border-box; font-family:sans-serif }
body { background: #465a77; height: 100vh; display: flex; justify-content: center; align-items: flex-start; padding-top: 60px; }
.forms-L, .forms-E { width: 350px; background: #fff; padding: 30px; border-radius: 15px; box-shadow: -2px 2px 8px #0000002f; margin-top: 30px; }
.learn-or-edu{ width: 500px; background: #becffc; padding: 30px; border-radius: 15px; box-shadow: -2px 2px 8px #0000002f; margin-top: 30px; display: flex; align-items: center; justify-content: center; gap: 70px; }
h1 { color: #ffffff; font-size: 50px; text-align: center; margin-bottom: 20px; }
h3{ padding-bottom: 20px; color: #0d688a; font-size: 150%; }
input, select, textarea, input[type="file"], button { width: 100%; display: block; padding: 10px; border: 1px solid #bbb; border-radius: 8px; margin-bottom: 12px; }
button:hover { background: #03455e; color: #fff; }
label{ display:block; margin:6px 0 4px; color:#000000; font-weight:600; }
.text-optional{ font-size: 12px; color: #bbb; }
.errorMsg{ color:red; font-weight:bold; margin-bottom:12px; font-size:13px; }
.hidden { display:none!important; }
.checks{ display: grid; grid-template-columns: auto 1fr; gap: 5px 8px; align-items: center; padding: 10px; padding-left: 50px; }
.radio-group { display: flex; align-items: center; justify-content: center; gap: 40px; }
.radio-group label { display: flex; align-items: center; gap: 8px; font-size: 18px; color: #0d688a; font-weight: bold; cursor: pointer; }
.radio-group input[type="radio"] { transform: scale(1.3); cursor: pointer; }
</style>
</head>
<body>
<div class="container">
<h1>Sign Up</h1>

<!-- اختيار نوع المستخدم -->
<div class="learn-or-edu <?php echo ($selectedType!="") ? 'hidden' : ''; ?>">
  <div class="radio-group">
    <label><input type="radio" name="type" value="learner"> Learner</label>
    <label><input type="radio" name="type" value="educator"> Educator</label>
  </div>
</div>

<!-- نموذج المتعلم -->
<div class="forms-L hidden">
<?php if(isset($_GET['err']) && $_GET['err']=="learner_exists") {
    echo "<p style='color:red; text-align:center; font-weight:bold;'>This email is already registered!</p>";
} ?>
<form action="signup_process.php" method="POST" enctype="multipart/form-data">
<h3>Learner Information</h3>
<label>First Name:*</label>
<input type="text" name="firstName" placeholder="Enter your first name" required>

<label>Last Name:*</label>
<input type="text" name="lastName" placeholder="Enter your last name" required>

<label>Email Address:*</label>
<input type="email" name="emailAddress" placeholder="Enter your email" required>

<label>Password:*</label>
<input type="password" name="password" placeholder="Enter your password" required>

<label>Profile Image:</label>
<input type="file" name="photoFileName" accept="image/*">
<p class="text-optional">Optional - A default image will be used if not provided</p>

<input type="hidden" name="userType" value="learner">
<button type="submit">Sign up as Learner</button>
</form>
</div>

<!-- نموذج المعلم -->
<div class="forms-E hidden">
<?php if(isset($_GET['err']) && $_GET['err']=="educator_exists") {
    echo "<p style='color:red; text-align:center; font-weight:bold;'>This email is already registered!</p>";
} ?>
<form id="teacherForm" action="signup_process.php" method="POST" enctype="multipart/form-data">
<h3>Educator Information</h3>
<label>First Name:*</label>
<input type="text" name="firstName" placeholder="Enter your first name" required>

<label>Last Name:*</label>
<input type="text" name="lastName" placeholder="Enter your last name" required>

<label>Email Address:*</label>
<input type="email" name="emailAddress" placeholder="Enter your email" required>

<label>Password:*</label>
<input type="password" name="password" placeholder="Enter your password" required>

<label>Profile Image:</label>
<input type="file" name="photoFileName" accept="image/*">
<p class="text-optional">Optional - A default image will be used if not provided</p>

<input type="hidden" name="userType" value="educator">

<label>Specializes in:*</label>
<div class="checks">
<input type="checkbox" id="check1" name="check[]" value="1"><label for="check1">Computer Networks</label>
<input type="checkbox" id="check2" name="check[]" value="2"><label for="check2">Database Systems</label>
<input type="checkbox" id="check3" name="check[]" value="3"><label for="check3">Web Development</label>
</div>
<p id="specialError" class="errorMsg" style="display:none;">Please select at least one specialization.</p>

<button type="submit">Sign up as Educator</button>
<?php if(isset($_GET['err']) && $_GET['err']=="educator_exists") echo "<p class='errorMsg'>This email is already registered!</p>"; ?>
</form>
</div>
</div>

<script>
const chooser = document.querySelector('.learn-or-edu');
const learnerForm = document.querySelector('.forms-L');
const educatorForm = document.querySelector('.forms-E');

document.querySelectorAll('.learn-or-edu input[name="type"]').forEach(rb=>{
    rb.addEventListener('change', ()=>{
        chooser.classList.add('hidden');
        if(rb.value==="learner"){
            learnerForm.classList.remove('hidden');
            educatorForm.classList.add('hidden');
        } else {
            educatorForm.classList.remove('hidden');
            learnerForm.classList.add('hidden');
        }
    });
});

// تحقق من اختيار تخصص واحد على الأقل
document.getElementById('teacherForm').addEventListener('submit', function(e){
    const checks = document.querySelectorAll('input[name="check[]"]');
    let checkedOne = false;
    checks.forEach(chk => { if(chk.checked) checkedOne = true; });
    const errorMsg = document.getElementById('specialError');
    if(!checkedOne){
        e.preventDefault();
        errorMsg.style.display = "block";
    } else {
        errorMsg.style.display = "none";
    }
});

// عرض النموذج الصحيح تلقائيًا إذا رجع المستخدم بسبب خطأ
const params = new URLSearchParams(window.location.search);
if(params.get('err') === 'learner_exists'){
    chooser.classList.add('hidden');
    learnerForm.classList.remove('hidden');
} 
if(params.get('err') === 'educator_exists'){
    chooser.classList.add('hidden');
    educatorForm.classList.remove('hidden');
}
</script>

</body>
</html>
