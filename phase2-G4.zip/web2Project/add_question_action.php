<?php
session_start();
include("db_connect.php");

if (empty($_SESSION['user_id']) || ($_SESSION['user_type'] ?? '') !== 'educator') {
    exit("Unauthorized access");
}

$quiz_id = (int)($_POST['quiz_id'] ?? 0);
$question = trim($_POST['question'] ?? '');
$answerA = trim($_POST['answerA'] ?? '');
$answerB = trim($_POST['answerB'] ?? '');
$answerC = trim($_POST['answerC'] ?? '');
$answerD = trim($_POST['answerD'] ?? '');
$correct = $_POST['correctAnswer'] ?? '';

if (!$quiz_id || !$question || !$answerA || !$answerB || !$answerC || !$answerD || !in_array($correct,['A','B','C','D'])) {
    exit("Missing or invalid fields.");
}

// Handle optional figure upload
$figureFileName = null;
if (!empty($_FILES['questionFigure']) && $_FILES['questionFigure']['error'] === UPLOAD_ERR_OK) {
    $ext = pathinfo($_FILES['questionFigure']['name'], PATHINFO_EXTENSION);
    $figureFileName = uniqid("q{$quiz_id}_", true) . ($ext ? ".".$ext : "");
    move_uploaded_file($_FILES['questionFigure']['tmp_name'], __DIR__ . "/image/" . $figureFileName);
}

// Insert into database
$stmt = $conn->prepare("INSERT INTO quizquestion 
    (quizID, question, questionFigureFileName, answerA, answerB, answerC, answerD, correctAnswer)
    VALUES (?,?,?,?,?,?,?,?)");
$stmt->bind_param("isssssss", $quiz_id, $question, $figureFileName, $answerA, $answerB, $answerC, $answerD, $correct);
$stmt->execute();
$stmt->close();

// Redirect back to quiz page
header("Location: quiz.php?quiz_id=" . $quiz_id);
exit;
