<?php
session_start();
if (empty($_SESSION['user_id']) || ($_SESSION['user_type'] ?? '') !== 'educator') {
    exit("Unauthorized access");
}
include("db_connect.php");

$qid = (int)($_POST['question_id'] ?? 0);
if (!$qid) exit("Question ID required.");

// استرجاع السؤال للتحقق من المالك
$stmt = $conn->prepare("
    SELECT qq.*, q.educatorID, q.id AS quiz_id 
    FROM quizquestion qq 
    JOIN quiz q ON qq.quizID=q.id 
    WHERE qq.id=?
");
$stmt->bind_param("i", $qid);
$stmt->execute();
$res = $stmt->get_result();
$question = $res->fetch_assoc();
$stmt->close();

if (!$question || $question['educatorID'] != $_SESSION['user_id']) exit("Permission denied.");

// معالجة البيانات المرسلة
$questionText = trim($_POST['question'] ?? '');
$answerA = trim($_POST['answerA'] ?? '');
$answerB = trim($_POST['answerB'] ?? '');
$answerC = trim($_POST['answerC'] ?? '');
$answerD = trim($_POST['answerD'] ?? '');
$correct = $_POST['correctAnswer'] ?? '';
$remove_old = isset($_POST['remove_old_image']) && $_POST['remove_old_image']=='1';

$figureFileName = $question['questionFigureFileName'];

// حذف الصورة القديمة إذا طلب المستخدم
if ($remove_old && $figureFileName) {
    $oldPath = __DIR__ . "/image/" . $figureFileName;
    if (file_exists($oldPath)) unlink($oldPath);
    $figureFileName = null;
}

// رفع صورة جديدة إذا تم رفعها
if (!empty($_FILES['questionFigure']) && $_FILES['questionFigure']['error'] !== UPLOAD_ERR_NO_FILE) {
    $f = $_FILES['questionFigure'];
    if ($f['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($f['name'], PATHINFO_EXTENSION);
        $newName = uniqid("q{$question['quiz_id']}_", true) . ($ext ? ".".$ext : "");
        if (move_uploaded_file($f['tmp_name'], __DIR__ . "/image/" . $newName)) {
            // حذف القديمة إذا كانت موجودة
            if ($figureFileName) {
                $oldPath = __DIR__ . "/image/" . $figureFileName;
                if (file_exists($oldPath)) unlink($oldPath);
            }
            $figureFileName = $newName;
        } else {
            exit("Failed to upload new image.");
        }
    } else {
        exit("File upload error.");
    }
}

// تحديث قاعدة البيانات
$stmt = $conn->prepare("
    UPDATE quizquestion 
    SET question=?, questionFigureFileName=?, answerA=?, answerB=?, answerC=?, answerD=?, correctAnswer=? 
    WHERE id=?
");
$stmt->bind_param("sssssssi", $questionText, $figureFileName, $answerA, $answerB, $answerC, $answerD, $correct, $qid);
$stmt->execute();
$stmt->close();

// إعادة التوجيه لصفحة الاختبار
header("Location: quiz.php?quiz_id=".$question['quiz_id']);
exit;
